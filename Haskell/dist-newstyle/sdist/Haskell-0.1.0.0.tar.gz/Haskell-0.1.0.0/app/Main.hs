module Main where

import qualified MyLib (someFunc)
import qualified Parser

main :: IO ()
main = do
  putStrLn "Hello, Haskell!"
  MyLib.someFunc
 